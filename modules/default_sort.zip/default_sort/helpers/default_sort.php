<?php defined("SYSPATH") or die("No direct script access.");

class default_sort_Core {
}

# vim: tabstop=4 softtabstop=4 shiftwidth=4 expandtab:
