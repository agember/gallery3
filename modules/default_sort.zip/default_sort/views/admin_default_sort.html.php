<?php defined("SYSPATH") or die("No direct script access.") ?>	

<div id="g-admin-code-block">
    <h2><?= t("Default Sort Order") ?></h2>

    <p><?= t("Set default sort order and column for newly-created albums."); ?></p>

    <div class="g-block-content">
        <?php echo $form; ?>
    </div>
</div>
