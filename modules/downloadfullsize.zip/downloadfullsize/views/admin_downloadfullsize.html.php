<?php defined("SYSPATH") or die("No direct script access.") ?>
<div id="g-download-fullsize-admin">
  <h2> <?= t("Download Fullsize Links") ?> </h2>
  <?= $downloadlinks_form ?>
</div>
