<?php defined("SYSPATH") or die("No direct script access.") ?>  
<div id="g-admin-code-block">
  <h2><?= t("Menu Links Administration") ?></h2>
  <?= $form ?>
</div>
