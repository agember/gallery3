<?php defined("SYSPATH") or die("No direct script access.") ?>
<h1><?= module::get_var("menu_links", "title"); ?></h1>
<?= module::get_var("menu_links", "url"); ?>
