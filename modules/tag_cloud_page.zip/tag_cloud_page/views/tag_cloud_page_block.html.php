<?php defined("SYSPATH") or die("No direct script access.") ?>
<a href="<?= url::site("tag_cloud_page"); ?>">View cloud</a>
