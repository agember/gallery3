<?php defined("SYSPATH") or die("No direct script access.") ?>
<div id="g-xmp-admin">
<h2> <?= t("XMP Settings") ?> </h2>
<?= $xmp_form ?>
</div>

